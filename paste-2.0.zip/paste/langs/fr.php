<?php
/*
 * Language File: French
 */

$lang = array();

?>