# Paste 2.0
[![Download PASTE](https://img.shields.io/sourceforge/dw/phpaste.svg)](https://sourceforge.net/projects/phpaste/files/latest/download)
[![Download PASTE](https://img.shields.io/sourceforge/dt/phpaste.svg)](https://sourceforge.net/projects/phpaste/files/latest/download)

Paste is forked from the original source pastebin.com used before it was bought.
The original source is available from the previous owner's **[GitHub repository](https://github.com/lordelph/pastebin)**

If you would like to contribute to developing Paste please feel free to find me on IRC.

A demo of Paste is available on our homepage at **[SourceForge](http://phpaste.sourceforge.net/demo)**

A public version can be found at **[PasteThis](http://pastethis.in)**

[![Frontend](http://i.imgur.com/z6MVaES.png)](http://pastethis.in/)

Requirements: Apache + PHP 5.3.7 (or later) [PHP5.5+ recommended] & MySQL. (GD required for Captcha)
===

Install
===
* Create a database for PASTE.
* Upload all files to a webfolder
* Point your browser to http://yourpas.te/installation/install
* Input some settings, DELETE the install folder and you're ready to go.

Any bugs can be reported at:
http://bitbucket.org/j-samuel/paste/issues/new/

You can find support on IRC by connecting to irc.collectiveirc.net in channel #PASTE

---

Changelog for 2.0
===
* Installer [done]
* Admin dashboard [done]
* Reworked archives [done]
* User accounts (incl. Social Integration) [done]

Lots of changes, a much needed update.

[![Backend](http://i.imgur.com/aP3FxGq.png)](http://pastethis.in/)

---

Paste now supports pastes of upto 4GB in size, and this is configurable in config.php

However, this relies on the value of post_max_size in your PHP configuration file.

```php
// Max paste size in MB. This value should always be below the value of
// post_max_size in your PHP configuration settings (php.ini) or empty errors will occur.
// The value we got on installation of Paste was: post_max_size = 1G
// Otherwise, the maximum value that can be set is 4000 (4GB)
$pastelimit = "1"; // 0.5 = 512 kilobytes, 1 = 1MB
```

To enable registration with OAUTH see this block in config.php

```php
// OAUTH (to enable, change to yes and edit)
$enablefb = "no";
$enablegoog = "no";

// "CHANGE THIS" = Replace with your details
// Facebook
define('FB_APP_ID', 'CHANGE THIS'); // Your application ID, see https://developers.facebook.com/docs/apps/register
define('FB_APP_SECRET', 'CHANGE THIS');    // What's your Secret key

// Google 
define('G_Client_ID', 'CHANGE THIS'); // Get a Client ID from https://console.developers.google.com/projectselector/apis/library
define('G_Client_Secret', 'CHANGE THIS'); // What's your Secret ID
define('G_Redirect_Uri', 'http://urltoyour/installation/oauth/google.php'); // Leave this as is
define('G_Application_Name', 'Paste'); // Make sure this matches the name of your application
```

Everything else can be configured using the admin panel.

---


Credits
===
Paul Dixon for developing **[the original pastebin.com](https://github.com/lordelph/pastebin)**

Roberto Rodríguez (roberto.rodriguez.pino[AT]gmail.com) for PostgreSQL support.

The Paste theme was built using Bootstrap, jQuery and various jQuery plugins for
present and future features, but we do try to keep it bloat free.
Icons are provided by FontAwesome.
