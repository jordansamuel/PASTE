<?php
/*
 * $ID Project: Paste 2.0 - J.Samuel
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License in LIC.txt for more details.
 */
error_reporting(1);
?>

<div class="content">
  <!-- START CONTAINER -->
  <div class="container-padding">
    <!-- Start Row -->
    <div class="row">
      <!-- Start Panel -->
		<div class="col-md-10 col-lg-10">
		  <div class="panel panel-default">
			<div class="panel-title" style="text-align:center;">
				<?php echo $lang['60']; ?> <?php echo $total_pastes; ?> <a class="btn btn-light"  href="mypastes.php" title="View all pastes">View Pastes</a>
			</div>
			
				<div class="login-form" style="padding-top: 0px;">
				<?php 
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
				if (isset($success)) {
					echo '<div class="paste-alert alert3" style="text-align:center;">
					'.$success.'
					</div>'; 
					} elseif (isset($error)) {
						echo '<div class="paste-alert alert6" style="text-align:center;">
					'.$error.'
					</div>'; 
					}
				}
				?>
			  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
					<div class="form-area">
					  <div class="group">
						<input disabled="" type="text" class="form-control"  name="username" style="cursor:not-allowed;" placeholder="<?php echo $user_username; ?>">
						<i class="fa fa-user"></i>
					  </div>
					  
					  <div class="group">
						<input <?php if ($user_verified == "1") { echo 'disabled=""'; } ?> type="text" class="form-control" name="email" placeholder="<?php echo $user_email_id; ?>">
						<i class="fa fa-envelope-o"></i>
					  </div>

					  <h5><?php echo $lang['65']; ?></h5>
					  
					  <div class="group">
						<input type="password" class="form-control" name="old_password" placeholder="<?php echo $lang['66']; ?>">
						<i class="fa fa-key"></i>
					  </div>
					  
					  <div class="group">
						<input type="password" class="form-control" name="password" placeholder="<?php echo $lang['67']; ?>">
						<i class="fa fa-pencil"></i>
					  </div>

					  <div class="group">
						<input type="password" class="form-control" name="cpassword" placeholder="<?php echo $lang['68']; ?>">
						<i class="fa fa-check"></i>
					  </div>
					  <button type="submit" name="submit" class="btn btn-default btn-block">Submit</button>
					</div>
				  </form>
				</div>
			</div>
		</div>
<?php require_once('theme/'.$default_theme.'/sidebar.php'); ?>