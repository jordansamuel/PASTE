<?php
/*
 * $ID Project: Paste 2.0 - J.Samuel
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License in LIC.txt for more details.
 */
error_reporting(1);
?>

<div class="content">
  <!-- START CONTAINER -->
  <div class="container-padding">
    <!-- Start Row -->
    <div class="row">
      <!-- Start Panel -->
		<div class="col-md-10 col-lg-10">
		  <div class="panel panel-default">
			<div class="panel-title">
			  <span class="badge"><i class="fa fa-code fa-lg" aria-hidden="true"></i> <?php echo strtoupper($p_code); ?></span>
			  <span class="badge"><i class="fa fa-eye fa-lg" aria-hidden="true"></i> <?php echo $p_views; ?></span>
			  <h6 style="text-align: center;"><?php echo ucfirst($p_title); ?> <small><?php echo 'By ' . $p_member . ' on ' . $p_date ;?></small></h6>
			  <ul class="panel-tools">
				<li><a class="icon" href="."><i class="fa fa-plus-square fa-lg"></i></a></li>
				<li><a class="icon" href="<?php echo $p_download; ?>"><i class="fa fa-download fa-lg"></i></a></li>
				<li><a class="icon" href="javascript:togglev();"><i class="fa fa-list-ol fa-lg"></i></a></li>
				<li><a class="icon" href="#" onmouseover="selectText('paste');"><i class="fa fa-clipboard fa-lg"></i></a></li>
				<!-- <li><a class="icon search-tool"><i class="fa fa-search fa-lg"></i></a></li> -->
				<li><a class="icon expand-tool"><i class="fa fa-expand fa-lg"></i></a></li>
			  </ul>
			</div>

			<div class="panel-search" style="display: none;">
			  <form>
				<input type="text" class="form-control" placeholder="Search this paste">
				<i class="fa fa-search icon"></i>
			  </form>
			</div>

			<div class="panel-body" style="display: block;">
			<?php if (isset($error)) {
			echo '<div class="paste-alert alert6">' . $error . '</div>'; 
			} else {
			echo '<div id="paste">' . $p_content . '</div>';
			?>
			</div>
			<?php } ?>
		  </div>
		</div>
      <!-- End Panel -->
<?php require_once('theme/'.$default_theme.'/sidebar.php'); ?>
<?php echo $ads_2; ?> 