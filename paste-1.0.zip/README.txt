$ID PROJECT: Paste - README.txt, v1, EcKstasy - 17/03/2010/08:47 GMT+1 (dd/mm/yy/time)

Requirements: PHP, MySQL

1.1> Create a database for the pastebin.
1.2> Add the tables to the database (paste.sql)
2> Edit the configuration file to suit your needs (config.php)
3> Upload all of the files to the webserver.
If you want to use Apache's mod_rewrite for pastes,
simply edit htaccess.txt to suit your needs and rename it to .htaccess

If you find any bugs, which is highly doubtful; file a bug report at either:
https://sourceforge.net/tracker/?func=add&group_id=310876&atid=1308834
or http://bitbucket.org/eckstasy/paste/issues/new/

You can find support on IRC by connecting to irc.freenode.net in channel ##PASTE

Find our other web projects at http://escriptirc.com/
