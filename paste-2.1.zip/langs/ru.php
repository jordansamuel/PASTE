<?php
/*
 * Language File: Russian
 */

$lang = array();

?>