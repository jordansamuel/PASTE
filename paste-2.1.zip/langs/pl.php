<?php
/*
 * Language File: Polish
 */

$lang = array();

?>